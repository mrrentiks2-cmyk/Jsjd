package com.neondrift.wallpaper;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;

import java.util.Random;

/** Северное сияние: светящиеся ленты над силуэтом гор. */
final class AuroraScene extends Scene {
    private static final int SAMPLES = 48;

    private int n;
    private float[] base, amp, f1, f2, s1, s2, ph, hgt;
    private Paint[] fill, rays, edge, edgeGlow;
    private final Path ribbon = new Path(), line = new Path();
    private final float[] topY = new float[SAMPLES + 1], xs = new float[SAMPLES + 1];

    private final Paint bg = new Paint(), star = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint farP = new Paint(Paint.ANTI_ALIAS_FLAG), nearP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Path farM, nearM;
    private float[] stX, stY, stPh;
    private float flash, bump, bumpX;

    @Override
    protected void onSetup() {
        n = U.clamp(Math.round(3 + 2 * cfg.density), 3, 7);
        base = new float[n];
        amp = new float[n];
        f1 = new float[n];
        f2 = new float[n];
        s1 = new float[n];
        s2 = new float[n];
        ph = new float[n];
        hgt = new float[n];
        fill = new Paint[n];
        rays = new Paint[n];
        edge = new Paint[n];
        edgeGlow = new Paint[n];
        PorterDuffXfermode add = U.add();
        int[] tones = {pal.a, pal.b, U.mix(pal.a, pal.c, 0.5f), U.mix(pal.b, pal.c, 0.4f)};
        for (int i = 0; i < n; i++) {
            base[i] = h * (0.1f + 0.4f * (i + U.rand(0.1f, 0.9f)) / n);
            amp[i] = h * U.rand(0.03f, 0.07f);
            f1[i] = U.rand(0.6f, 1.6f);
            f2[i] = U.rand(1.8f, 3.5f);
            s1[i] = U.rand(0.25f, 0.6f);
            s2[i] = U.rand(0.15f, 0.45f);
            ph[i] = U.rand(0, U.TAU);
            hgt[i] = h * U.rand(0.18f, 0.34f);
            int col = tones[i % tones.length];

            Shader grad = U.vgrad(base[i] - amp[i] * 1.3f, base[i] + hgt[i] + amp[i],
                    new int[]{U.alpha(col, 0), U.alpha(col, 255), U.alpha(col, 90), U.alpha(col, 0)},
                    new float[]{0f, 0.12f, 0.5f, 1f});
            Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
            f.setShader(grad);
            f.setXfermode(add);
            fill[i] = f;

            Paint ray = new Paint(Paint.ANTI_ALIAS_FLAG);
            ray.setShader(grad);
            ray.setStyle(Paint.Style.STROKE);
            ray.setStrokeWidth(1.8f * scale);
            ray.setXfermode(add);
            rays[i] = ray;

            Paint e = new Paint(Paint.ANTI_ALIAS_FLAG);
            e.setStyle(Paint.Style.STROKE);
            e.setStrokeWidth(2.2f * scale);
            e.setColor(U.alpha(U.mix(col, U.WHITE, 0.4f), 95));
            e.setXfermode(add);
            edge[i] = e;

            Paint eg = new Paint(Paint.ANTI_ALIAS_FLAG);
            eg.setStyle(Paint.Style.STROKE);
            eg.setStrokeWidth(14f * scale);
            eg.setColor(U.alpha(col, 40));
            eg.setXfermode(add);
            edgeGlow[i] = eg;
        }

        bg.setShader(U.vgrad(0, h, new int[]{pal.bgTop, pal.bgBottom, U.mix(pal.bgBottom, pal.a, 0.12f)},
                new float[]{0f, 0.7f, 1f}));

        int ns = Math.max(20, Math.round(90 * cfg.density * Math.max(0.5f, areaK())));
        stX = new float[ns];
        stY = new float[ns];
        stPh = new float[ns];
        for (int i = 0; i < ns; i++) {
            stX[i] = U.rand(0, w);
            stY[i] = U.rand(0, h * 0.75f);
            stPh[i] = U.rand(0, U.TAU);
        }

        Random r = new Random(11);
        farM = mountains(r, h * 0.8f, h * 0.12f, 18);
        nearM = mountains(r, h * 0.87f, h * 0.09f, 26);
        farP.setColor(U.mix(pal.bgBottom, U.BLACK, 0.35f));
        nearP.setColor(U.mix(pal.bgTop, U.BLACK, 0.6f));
        flash = 0f;
        bump = 0f;
    }

    private Path mountains(Random r, float baseY, float height, int peaks) {
        Path p = new Path();
        float x0 = -w * 0.1f, x1 = w * 1.1f;
        p.moveTo(x0, h);
        float step = (x1 - x0) / peaks;
        for (int i = 0; i <= peaks; i++) {
            float x = x0 + i * step;
            float y = baseY - height * (0.25f + 0.75f * r.nextFloat()) * (i % 2 == 0 ? 1f : 0.55f);
            p.lineTo(x, y);
        }
        p.lineTo(x1, h);
        p.close();
        return p;
    }

    @Override
    protected void update(float dt, float realDt) {
        flash *= (float) Math.exp(-1.6 * realDt);
        bump *= (float) Math.exp(-1.2 * realDt);
    }

    @Override
    protected void draw(Canvas c) {
        c.drawRect(0, 0, w, h, bg);
        for (int i = 0; i < stX.length; i++) {
            float tw = 0.5f + 0.5f * U.sin(time * 1.4f + stPh[i]);
            star.setColor(U.alpha(U.WHITE, Math.round(60 + 150 * tw)));
            c.drawCircle(stX[i], stY[i], (0.6f + 0.6f * tw) * scale, star);
        }

        float pp = par() * 0.06f;
        float spanX = w * 1.1f, startX = -w * 0.05f;
        for (int i = 0; i < n; i++) {
            ribbon.reset();
            line.reset();
            for (int k = 0; k <= SAMPLES; k++) {
                float x = startX + spanX * k / SAMPLES;
                float u = x / w + pp;
                float y = base[i] + amp[i] * (0.7f * U.sin(u * f1[i] * U.TAU + time * s1[i] + ph[i])
                        + 0.3f * U.sin(u * f2[i] * U.TAU - time * s2[i] + ph[i] * 1.7f));
                if (bump > 0.01f) {
                    float d = (x - bumpX) / (w * 0.18f);
                    y += bump * h * 0.05f * (float) Math.exp(-d * d) * U.sin(time * 6f + i);
                }
                xs[k] = x;
                topY[k] = y;
                if (k == 0) {
                    ribbon.moveTo(x, y);
                    line.moveTo(x, y);
                } else {
                    ribbon.lineTo(x, y);
                    line.lineTo(x, y);
                }
            }
            for (int k = SAMPLES; k >= 0; k--) {
                float u = xs[k] / w;
                float yb = topY[k] + hgt[i] * (0.75f + 0.25f * U.sin(u * 7f + time * 0.8f + i));
                ribbon.lineTo(xs[k], yb);
            }
            ribbon.close();
            float boost = 1f + flash * 0.6f;
            fill[i].setAlpha(Math.round(U.clamp(70f * boost, 0f, 255f)));
            c.drawPath(ribbon, fill[i]);

            // вертикальные лучи — то, что делает ленту похожей на занавес сияния
            int nr = Math.max(12, Math.round(w / (5f * scale)));
            for (int j = 0; j < nr; j++) {
                float x = startX + spanX * (j + 0.5f + 0.35f * U.sin(j * 12.9898f + i)) / nr;
                float fi = (x - startX) / spanX * SAMPLES;
                int k0 = U.clamp((int) fi, 0, SAMPLES - 1);
                float top = U.lerp(topY[k0], topY[k0 + 1], fi - k0);
                float u = x / scale;
                float a = (0.5f + 0.5f * U.sin(u * 0.05f + time * 1.3f + i))
                        * (0.5f + 0.5f * U.sin(u * 0.013f - time * 0.4f + i * 2.1f))
                        * (0.6f + 0.4f * U.sin(u * 0.173f + time * 2.3f + i * 0.7f));
                float len = hgt[i] * (0.45f + 0.55f * (0.5f + 0.5f * U.sin(u * 0.031f + time * 0.7f + i * 1.7f)));
                rays[i].setAlpha(Math.round(U.clamp((25f + 150f * a) * boost, 0f, 255f)));
                c.drawLine(x, top, x, top + len, rays[i]);
            }
            c.drawPath(line, edgeGlow[i]);
            c.drawPath(line, edge[i]);
        }

        c.save();
        c.translate(-par() * w * 0.02f, 0);
        c.drawPath(farM, farP);
        c.restore();
        c.save();
        c.translate(-par() * w * 0.045f, 0);
        c.drawPath(nearM, nearP);
        c.restore();
    }

    @Override
    protected void onTouch(float x, float y, int action) {
        if (!isPress(action)) return;
        flash = 1f;
        bump = 1f;
        bumpX = x;
    }
}
