package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.Random;

/** Неон-город: закатное солнце, силуэты небоскрёбов, бегущая сетка, падающие звёзды. */
final class CityScene extends Scene {
    private float horizon;
    private Bitmap sun, sunGlow, farCity, nearCity, antennaGlow, starHead;
    private int cityW;
    private float sunR, sunCx, sunCy;

    private final Paint sky = new Paint(), floor = new Paint(), haze = new Paint(), horizonGlow = new Paint();
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint gridThin = new Paint(Paint.ANTI_ALIAS_FLAG), gridWide = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint horizonLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG), streak = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float[] stX, stY, stPh, stR;
    private float[] vLines;
    private float gridPhase;
    private float[] antX, antY, antPh;

    private static final int SS = 5;
    private static final float SS_LIFE = 0.9f;
    private final float[] ssX = new float[SS], ssY = new float[SS], ssVX = new float[SS], ssVY = new float[SS], ssT = new float[SS];
    private float autoStar;

    @Override
    protected void onSetup() {
        horizon = h * 0.6f;

        sky.setShader(U.vgrad(0, horizon,
                new int[]{pal.bgTop, pal.bgBottom, U.mix(pal.bgBottom, pal.a, 0.45f), U.mix(pal.a, pal.c, 0.35f)},
                new float[]{0f, 0.5f, 0.86f, 1f}));
        floor.setShader(U.vgrad(horizon, h,
                new int[]{U.mix(pal.bgBottom, pal.a, 0.3f), U.mix(pal.bgTop, pal.bgBottom, 0.5f), pal.bgTop},
                new float[]{0f, 0.3f, 1f}));
        float hz = (h - horizon) * 0.2f;
        haze.setShader(new LinearGradient(0, horizon, 0, horizon + hz,
                U.alpha(U.mix(pal.a, pal.c, 0.3f), 150), U.alpha(pal.a, 0), Shader.TileMode.CLAMP));
        float hg = 34f * scale;
        horizonGlow.setShader(U.vgrad(horizon - hg, horizon + hg,
                new int[]{U.alpha(pal.c, 0), U.alpha(U.mix(pal.c, pal.a, 0.3f), 170), U.alpha(pal.a, 0)},
                new float[]{0f, 0.5f, 1f}));
        horizonLine.setColor(U.mix(pal.c, U.WHITE, 0.55f));
        horizonLine.setStrokeWidth(2.2f * scale);

        gridThin.setShader(new LinearGradient(0, horizon, 0, h,
                U.alpha(pal.b, 50), U.alpha(U.mix(pal.b, U.WHITE, 0.3f), 255), Shader.TileMode.CLAMP));
        gridThin.setStrokeWidth(1.5f * scale);
        gridWide.setShader(new LinearGradient(0, horizon, 0, h,
                U.alpha(pal.b, 0), U.alpha(pal.b, 95), Shader.TileMode.CLAMP));
        gridWide.setStrokeWidth(7f * scale);
        vLines = new float[31 * 4];

        sunR = Math.min(w * 0.4f, h * 0.22f);
        sunCx = w / 2f;
        sunCy = horizon - sunR * 0.16f;
        sun = makeSun(Math.round(sunR * 2f));
        sunGlow = U.glow(pal.a, false);
        antennaGlow = U.glow(pal.a, true);
        starHead = U.glow(pal.c, true);

        farCity = makeCity(false);
        nearCity = makeCity(true);

        int n = Math.max(20, Math.round(120 * cfg.density * Math.max(0.5f, areaK())));
        stX = new float[n];
        stY = new float[n];
        stPh = new float[n];
        stR = new float[n];
        for (int i = 0; i < n; i++) {
            stX[i] = U.rand(0, w);
            stY[i] = horizon * 0.8f * (float) Math.pow(U.R.nextFloat(), 1.5);
            stPh[i] = U.rand(0, U.TAU);
            stR[i] = U.rand(0.5f, 1.6f) * scale;
        }
        streak.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < SS; i++) ssT[i] = 0f;
        autoStar = U.rand(1.5f, 4f);
    }

    private Bitmap makeSun(int size) {
        size = Math.max(8, size);
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float r = size / 2f;
        p.setShader(U.vgrad(0, size,
                new int[]{U.mix(pal.c, U.WHITE, 0.25f), pal.c, pal.a, U.mix(pal.a, pal.b, 0.35f)},
                new float[]{0f, 0.28f, 0.66f, 1f}));
        c.drawCircle(r, r, r, p);
        Paint clear = new Paint();
        clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        float y = size * 0.5f, gap = size * 0.012f;
        while (y < size) {
            c.drawRect(0, y, size, y + gap, clear);
            y += gap + size * 0.06f;
            gap *= 1.35f;
        }
        return b;
    }

    private Bitmap makeCity(boolean near) {
        cityW = Math.round(w * 1.24f);
        int ch = Math.max(4, Math.round(h * (near ? 0.27f : 0.33f)));
        Bitmap b = Bitmap.createBitmap(cityW, ch, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint body = new Paint();
        body.setColor(near ? U.mix(pal.bgTop, U.BLACK, 0.4f) : U.mix(pal.bgBottom, pal.a, 0.2f));
        Paint win = new Paint();
        Random r = new Random(near ? 7 : 3);
        float u = scale;
        ArrayList<float[]> ants = new ArrayList<>();
        float x = -u * 8f;
        while (x < cityW) {
            float bw = u * (near ? 30f + r.nextFloat() * 52f : 22f + r.nextFloat() * 36f);
            // в центре дома ниже, чтобы солнце было видно; к краям город растёт
            float dist = Math.min(1f, Math.abs((x + bw / 2f) - cityW / 2f) / (cityW * 0.42f));
            float tall = near ? 0.3f + 0.7f * (float) Math.pow(dist, 0.8) : 0.5f + 0.5f * dist;
            float bh = ch * (near ? 0.3f + r.nextFloat() * 0.65f : 0.3f + r.nextFloat() * 0.65f) * tall;
            bh = Math.min(bh, ch * 0.9f);
            float top = ch - bh;
            c.drawRect(x, top, x + bw, ch, body);
            if (r.nextFloat() < 0.35f) {
                c.drawRect(x + bw * 0.2f, top - u * 10f, x + bw * 0.8f, top, body);
                top -= u * 10f;
            }
            if (r.nextFloat() < 0.3f) {
                float ax = x + bw * 0.5f, ah = u * (12f + r.nextFloat() * 30f);
                c.drawRect(ax - u * 0.8f, top - ah, ax + u * 0.8f, top, body);
                if (near) ants.add(new float[]{ax, top - ah});
            }
            if (near) {
                float ww = u * 3f, wh = u * 4.2f, gx = u * 7f, gy = u * 9f;
                for (float wy = top + u * 8f; wy < ch - u * 6f; wy += gy) {
                    for (float wx = x + u * 5f; wx < x + bw - u * 5f - ww; wx += gx) {
                        if (r.nextFloat() < 0.16f) {
                            int col = r.nextFloat() < 0.62f ? pal.b : pal.a;
                            win.setColor(U.alpha(col, 140 + r.nextInt(115)));
                            c.drawRect(wx, wy, wx + ww, wy + wh, win);
                        }
                    }
                }
                if (r.nextFloat() < 0.14f && bh > ch * 0.3f) {
                    win.setColor(U.alpha(r.nextBoolean() ? pal.a : pal.c, 235));
                    float sx = x + bw * 0.12f;
                    c.drawRect(sx, top + u * 12f, sx + u * 2.2f, top + bh * 0.55f, win);
                }
            }
            x += bw + u * (r.nextFloat() * 10f - 3f);
        }
        if (near) {
            antX = new float[ants.size()];
            antY = new float[ants.size()];
            antPh = new float[ants.size()];
            for (int i = 0; i < ants.size(); i++) {
                antX[i] = ants.get(i)[0];
                antY[i] = ants.get(i)[1];
                antPh[i] = r.nextFloat() * U.TAU;
            }
        }
        return b;
    }

    private void launchStar(float x, float y) {
        int slot = 0;
        for (int i = 0; i < SS; i++) if (ssT[i] <= 0f) { slot = i; break; }
        float sp = w * U.rand(0.9f, 1.3f);
        ssX[slot] = x;
        ssY[slot] = y;
        ssVX[slot] = -sp * 0.86f;
        ssVY[slot] = sp * 0.5f;
        ssT[slot] = SS_LIFE;
    }

    @Override
    protected void update(float dt, float realDt) {
        gridPhase += dt * 0.55f;
        autoStar -= dt;
        if (autoStar <= 0f) {
            launchStar(U.rand(w * 0.35f, w * 1.05f), U.rand(0, horizon * 0.35f));
            autoStar = U.rand(3.5f, 9f);
        }
        for (int i = 0; i < SS; i++) {
            if (ssT[i] <= 0f) continue;
            ssX[i] += ssVX[i] * dt;
            ssY[i] += ssVY[i] * dt;
            ssT[i] -= dt;
        }
    }

    @Override
    protected void draw(Canvas c) {
        float p = par();
        c.drawRect(0, 0, w, horizon + 1, sky);

        for (int i = 0; i < stX.length; i++) {
            float tw = 0.55f + 0.45f * U.sin(time * 1.7f + stPh[i]);
            dot.setColor(U.alpha(U.WHITE, Math.round(tw * 210)));
            c.drawCircle(stX[i] - p * w * 0.01f, stY[i], stR[i], dot);
        }

        float sx = sunCx - p * w * 0.015f;
        sprite(c, sunGlow, sx, sunCy, sunR * 2.2f, 210);
        tmp.set(sx - sunR, sunCy - sunR, sx + sunR, sunCy + sunR);
        c.drawBitmap(sun, null, tmp, bmp);

        float base = (cityW - w) / 2f;
        c.drawBitmap(farCity, -base - p * w * 0.035f, horizon - farCity.getHeight(), bmp);
        float nx = -base - p * w * 0.08f;
        float ny = horizon - nearCity.getHeight();
        c.drawBitmap(nearCity, nx, ny, bmp);
        for (int i = 0; i < antX.length; i++) {
            float blink = U.sin(time * 2.2f + antPh[i]);
            if (blink > 0.15f) sprite(c, antennaGlow, nx + antX[i], ny + antY[i], 6f * scale, Math.round(255 * blink));
        }

        c.drawRect(0, horizon, w, h, floor);
        drawGrid(c, p);
        c.drawRect(0, horizon, w, horizon + (h - horizon) * 0.2f, haze);
        float hg = 34f * scale;
        c.drawRect(0, horizon - hg, w, horizon + hg, horizonGlow);
        c.drawLine(0, horizon, w, horizon, horizonLine);

        for (int i = 0; i < SS; i++) {
            if (ssT[i] <= 0f) continue;
            float life = ssT[i] / SS_LIFE;
            for (int k = 0; k < 4; k++) {
                float t0 = 0.035f * k, t1 = 0.035f * (k + 1);
                streak.setStrokeWidth((2.4f - k * 0.45f) * scale);
                streak.setColor(U.alpha(U.mix(U.WHITE, pal.c, k / 3f), Math.round(255 * life * (1f - k / 4f))));
                c.drawLine(ssX[i] - ssVX[i] * t0, ssY[i] - ssVY[i] * t0,
                        ssX[i] - ssVX[i] * t1, ssY[i] - ssVY[i] * t1, streak);
            }
            sprite(c, starHead, ssX[i], ssY[i], 9f * scale, Math.round(255 * life));
        }
    }

    private void drawGrid(Canvas c, float p) {
        float vx = w / 2f - p * w * 0.12f;
        int nv = vLines.length / 4, half = nv / 2;
        float top = w * 0.012f, bottom = w * 0.19f;
        for (int i = 0; i < nv; i++) {
            int k = i - half;
            vLines[i * 4] = vx + k * top;
            vLines[i * 4 + 1] = horizon;
            vLines[i * 4 + 2] = vx + k * bottom;
            vLines[i * 4 + 3] = h;
        }
        c.drawLines(vLines, gridWide);
        c.drawLines(vLines, gridThin);
        int nh = 14;
        float ph = U.fract(gridPhase);
        for (int j = 0; j < nh; j++) {
            float s = (j + ph) / nh;
            float y = horizon + (h - horizon) * (float) Math.pow(s, 2.2);
            c.drawLine(0, y, w, y, gridWide);
            c.drawLine(0, y, w, y, gridThin);
        }
    }

    @Override
    protected void onTouch(float x, float y, int action) {
        if (isPress(action) && y < horizon) launchStar(x, y);
    }
}
