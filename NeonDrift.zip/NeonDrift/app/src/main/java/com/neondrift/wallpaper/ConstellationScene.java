package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.MotionEvent;

/** Созвездия: дрейфующие узлы, связи между близкими точками, палец притягивает сеть. */
final class ConstellationScene extends Scene {
    private int n;
    private float[] x, y, vx, vy, ix, iy, sz, ph;
    private int[] col;
    private int[] colors;
    private float link, margin;
    private Bitmap[] glows;
    private Bitmap nebA, nebB;
    private final Paint bg = new Paint(), lp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean holding;
    private float hx, hy;
    private long lastMove;

    @Override
    protected void onSetup() {
        n = U.clamp(Math.round(95 * cfg.density * areaK() + 14), 18, 220);
        link = Math.min(w, h) * 0.27f;
        margin = w * 0.08f;
        x = new float[n];
        y = new float[n];
        vx = new float[n];
        vy = new float[n];
        ix = new float[n];
        iy = new float[n];
        sz = new float[n];
        ph = new float[n];
        col = new int[n];
        for (int i = 0; i < n; i++) {
            x[i] = U.rand(-margin, w + margin);
            y[i] = U.rand(-margin, h + margin);
            float a = U.rand(0, U.TAU), s = U.rand(8f, 26f) * scale;
            vx[i] = U.cos(a) * s;
            vy[i] = U.sin(a) * s;
            sz[i] = U.rand(1.4f, 3.4f) * scale;
            ph[i] = U.rand(0, U.TAU);
            col[i] = U.R.nextInt(3);
        }
        colors = new int[]{pal.a, pal.b, pal.c};
        glows = new Bitmap[]{U.glow(pal.a, true), U.glow(pal.b, true), U.glow(pal.c, true)};
        nebA = U.glow(pal.a, false);
        nebB = U.glow(pal.b, false);
        bg.setShader(U.vgrad(0, h, new int[]{pal.bgTop, pal.bgBottom, pal.bgTop}, new float[]{0f, 0.6f, 1f}));
        lp.setStrokeWidth(1.4f * scale);
        lp.setStrokeCap(Paint.Cap.ROUND);
        holding = false;
    }

    @Override
    protected void update(float dt, float realDt) {
        if (holding && SystemClock.uptimeMillis() - lastMove > 2500) holding = false;
        float decay = (float) Math.exp(-2.2 * realDt);
        float reach = link * 1.6f;
        float wrapW = w + 2 * margin, wrapH = h + 2 * margin;
        for (int i = 0; i < n; i++) {
            if (holding) {
                float dx = hx - x[i], dy = hy - y[i];
                float d2 = dx * dx + dy * dy;
                if (d2 < reach * reach) {
                    float d = (float) Math.sqrt(d2) + 1f;
                    float f = 260f * scale * realDt * (1f - d / reach);
                    ix[i] += dx / d * f;
                    iy[i] += dy / d * f;
                }
            }
            ix[i] *= decay;
            iy[i] *= decay;
            x[i] += (vx[i] + ix[i]) * dt;
            y[i] += (vy[i] + iy[i]) * dt;
            if (x[i] < -margin) x[i] += wrapW;
            else if (x[i] > w + margin) x[i] -= wrapW;
            if (y[i] < -margin) y[i] += wrapH;
            else if (y[i] > h + margin) y[i] -= wrapH;
        }
    }

    @Override
    protected void draw(Canvas c) {
        c.drawRect(0, 0, w, h, bg);
        sprite(c, nebA, w * (0.25f + 0.08f * U.sin(time * 0.07f)), h * 0.3f, w * 0.75f, 80);
        sprite(c, nebB, w * 0.8f, h * (0.72f + 0.04f * U.cos(time * 0.05f)), w * 0.85f, 70);

        float shift = -par() * w * 0.05f;
        c.save();
        c.translate(shift, 0);
        float l2 = link * link;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                float dx = x[j] - x[i];
                if (dx > link || dx < -link) continue;
                float dy = y[j] - y[i];
                if (dy > link || dy < -link) continue;
                float d2 = dx * dx + dy * dy;
                if (d2 >= l2) continue;
                float k = 1f - (float) Math.sqrt(d2) / link;
                lp.setColor(U.alpha(colors[col[i]], Math.round(k * (0.35f + 0.65f * k) * 230)));
                c.drawLine(x[i], y[i], x[j], y[j], lp);
            }
        }
        if (holding) {
            float fx = hx, fy = hy;
            float reach = link * 1.2f;
            for (int i = 0; i < n; i++) {
                float dx = x[i] - fx, dy = y[i] - fy;
                float d2 = dx * dx + dy * dy;
                if (d2 > reach * reach) continue;
                float k = 1f - (float) Math.sqrt(d2) / reach;
                lp.setColor(U.alpha(pal.c, Math.round(k * 200)));
                c.drawLine(fx, fy, x[i], y[i], lp);
            }
            sprite(c, glows[2], fx, fy, 22f * scale, 220);
        }
        for (int i = 0; i < n; i++) {
            float tw = 0.75f + 0.25f * U.sin(time * 2f + ph[i]);
            sprite(c, glows[col[i]], x[i], y[i], sz[i] * 6f, Math.round(245 * tw));
        }
        c.restore();
    }

    @Override
    protected void onTouch(float tx, float ty, int action) {
        float wx = tx + par() * w * 0.05f;
        if (isPress(action)) {
            float reach = link * 1.3f;
            for (int i = 0; i < n; i++) {
                float dx = x[i] - wx, dy = y[i] - ty;
                float d = (float) Math.sqrt(dx * dx + dy * dy) + 1f;
                if (d > reach) continue;
                float f = 520f * scale * (1f - d / reach);
                ix[i] += dx / d * f;
                iy[i] += dy / d * f;
            }
        }
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            holding = true;
            hx = wx;
            hy = ty;
            lastMove = SystemClock.uptimeMillis();
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            holding = false;
        }
    }
}
