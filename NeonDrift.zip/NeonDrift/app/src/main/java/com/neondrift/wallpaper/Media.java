package com.neondrift.wallpaper;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Импорт фото и видео во внутреннее хранилище и генерация миниатюр. */
final class Media {
    private Media() {}

    /** Копирует снимок, поворачивает по EXIF и ужимает до 3200 px по длинной стороне. */
    static String importPhoto(Context ctx, Uri uri) {
        File tmp = new File(ctx.getCacheDir(), "import_photo.tmp");
        try {
            copy(ctx, uri, tmp);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(tmp.getAbsolutePath(), o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (Math.max(o.outWidth, o.outHeight) / sample > 3200) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            Bitmap b = BitmapFactory.decodeFile(tmp.getAbsolutePath(), o2);
            if (b == null) return null;
            int rot = 0;
            try {
                ExifInterface ex = new ExifInterface(tmp.getAbsolutePath());
                int or = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (or == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                else if (or == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                else if (or == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
            } catch (Exception ignored) {
            }
            if (rot != 0) {
                Matrix m = new Matrix();
                m.postRotate(rot);
                Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (r != b) b.recycle();
                b = r;
            }
            File out = new File(ctx.getFilesDir(), "photo_" + System.currentTimeMillis() + ".jpg");
            try (FileOutputStream fos = new FileOutputStream(out)) {
                b.compress(Bitmap.CompressFormat.JPEG, 92, fos);
            }
            b.recycle();
            return out.getAbsolutePath();
        } catch (Throwable t) {
            return null;
        } finally {
            //noinspection ResultOfMethodCallIgnored
            tmp.delete();
        }
    }

    static String importVideo(Context ctx, Uri uri) {
        File out = new File(ctx.getFilesDir(), "video_" + System.currentTimeMillis() + ".mp4");
        try {
            copy(ctx, uri, out);
            return out.length() > 0 ? out.getAbsolutePath() : null;
        } catch (Throwable t) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            return null;
        }
    }

    static String importSound(Context ctx, Uri uri) {
        File out = new File(ctx.getFilesDir(), "sound_" + System.currentTimeMillis() + ".audio");
        try {
            copy(ctx, uri, out);
            return out.length() > 0 ? out.getAbsolutePath() : null;
        } catch (Throwable t) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            return null;
        }
    }

    /** Имя файла, как его видит пользователь, без расширения. */
    static String displayName(Context ctx, Uri uri) {
        String name = null;
        try (Cursor c = ctx.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
                null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) {
        }
        if (name == null || name.isEmpty()) return "Свой трек";
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static void copy(Context ctx, Uri uri, File dst) throws Exception {
        try (InputStream in = ctx.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(dst)) {
            if (in == null) throw new IllegalStateException("no stream");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    /** Удаляет старые импортированные файлы, кроме перечисленных. */
    static void cleanup(Context ctx, String... keep) {
        File[] files = ctx.getFilesDir().listFiles();
        if (files == null) return;
        for (File f : files) {
            String name = f.getName();
            if (!name.startsWith("photo_") && !name.startsWith("video_") && !name.startsWith("sound_")) continue;
            boolean used = false;
            for (String k : keep) if (k != null && k.equals(f.getAbsolutePath())) used = true;
            //noinspection ResultOfMethodCallIgnored
            if (!used) f.delete();
        }
    }

    /** Миниатюра сцены: 2,5 секунды симуляции и один кадр. */
    static Bitmap thumb(String id, WallConfig cfg, int w, int h) {
        try {
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            if (Scenes.isVideo(id)) {
                videoThumb(c, cfg, w, h);
                return b;
            }
            WallConfig t = cfg.copy();
            t.touch = false;
            t.brightness = 1f;
            t.speed = 1f;
            Scene s = Scenes.create(id);
            s.setup(w, h, t);
            for (int i = 0; i < 75; i++) s.step(1f / 30f);
            s.render(c);
            s.release();
            return b;
        } catch (Throwable e) {
            return null;
        }
    }

    private static void videoThumb(Canvas c, WallConfig cfg, int w, int h) {
        Palette p = cfg.palette();
        Paint bg = new Paint();
        bg.setShader(U.vgrad(0, h, new int[]{p.bgTop, U.mix(p.bgBottom, p.a, 0.3f)}, null));
        c.drawRect(0, 0, w, h, bg);
        Bitmap frame = null;
        if (cfg.videoPath != null && new File(cfg.videoPath).exists()) {
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(cfg.videoPath);
                frame = r.getFrameAtTime(1_000_000L);
            } catch (Exception ignored) {
            } finally {
                try {
                    r.release();
                } catch (Exception ignored) {
                }
            }
        }
        if (frame != null) {
            float s = Math.max(w / (float) frame.getWidth(), h / (float) frame.getHeight());
            float dw = frame.getWidth() * s, dh = frame.getHeight() * s;
            c.drawBitmap(frame, null, new RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f),
                    new Paint(Paint.FILTER_BITMAP_FLAG));
            frame.recycle();
        }
        float r = Math.min(w, h) * 0.17f;
        float cx = w / 2f, cy = h / 2f;
        Paint circle = new Paint(Paint.ANTI_ALIAS_FLAG);
        circle.setColor(0x66000000);
        c.drawCircle(cx, cy, r * 1.25f, circle);
        Path tri = new Path();
        tri.moveTo(cx - r * 0.4f, cy - r * 0.6f);
        tri.lineTo(cx + r * 0.62f, cy);
        tri.lineTo(cx - r * 0.4f, cy + r * 0.6f);
        tri.close();
        Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(0xFFFFFFFF);
        c.drawPath(tri, tp);
    }
}
