package com.neondrift.wallpaper;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.view.View;

/** Кружок палитры с диагональным градиентом трёх неоновых цветов. */
final class PaletteChip extends View {
    final Palette palette;
    private boolean chosen;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint back = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;

    PaletteChip(Context c, Palette p) {
        super(c);
        palette = p;
        dp = c.getResources().getDisplayMetrics().density;
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2f * dp);
        ring.setColor(0xFFF1ECFF);
        back.setColor(p.bgBottom);
    }

    void setChosen(boolean v) {
        chosen = v;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fill.setShader(new LinearGradient(0, 0, w, h, new int[]{palette.a, palette.b, palette.c}, null,
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(cx, cy);
        float inner = chosen ? r - 6f * dp : r - 3f * dp;
        c.drawCircle(cx, cy, inner + 1.5f * dp, back);
        c.drawCircle(cx, cy, inner, fill);
        if (chosen) c.drawCircle(cx, cy, r - 1.2f * dp, ring);
    }
}
