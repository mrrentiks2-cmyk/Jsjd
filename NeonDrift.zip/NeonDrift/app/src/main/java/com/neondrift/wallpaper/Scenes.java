package com.neondrift.wallpaper;

/** Каталог сцен. */
final class Scenes {
    private Scenes() {}

    static final String[] IDS = {
            "city", "rain", "stars", "aurora", "warp", "bokeh", "strings", "photo", "video"
    };

    static boolean isVideo(String id) { return "video".equals(id); }

    static String title(String id) {
        switch (id) {
            case "rain": return "Цифровой дождь";
            case "stars": return "Созвездия";
            case "aurora": return "Сияние";
            case "warp": return "Гиперпрыжок";
            case "bokeh": return "Боке";
            case "strings": return "Струны";
            case "photo": return "Твоё фото";
            case "video": return "Твоё видео";
            default: return "Неон-город";
        }
    }

    static String subtitle(String id) {
        switch (id) {
            case "rain": return "Потоки символов. Тап — всплеск в колонках";
            case "stars": return "Живая сеть точек. Палец притягивает узлы";
            case "aurora": return "Ленты света над горами. Тап — вспышка";
            case "warp": return "Полёт сквозь звёзды. Тап — ускорение";
            case "bokeh": return "Размытые огни. Тап — россыпь искр";
            case "strings": return "Неоновые струны. Тап — дёрнуть струну";
            case "photo": return "Твой снимок с параллаксом и эффектами";
            case "video": return "Любой ролик по кругу — без звука или со звуком";
            default: return "Закат, сетка и огни. Тап по небу — звезда";
        }
    }

    static Scene create(String id) {
        switch (id) {
            case "rain": return new RainScene();
            case "stars": return new ConstellationScene();
            case "aurora": return new AuroraScene();
            case "warp": return new WarpScene();
            case "bokeh": return new BokehScene();
            case "strings": return new StringsScene();
            case "photo": return new PhotoScene();
            default: return new CityScene();
        }
    }
}
