package com.neondrift.wallpaper;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/** Неоновые струны: натянуты между краями экрана, колышутся и дрожат от касания. */
final class StringsScene extends Scene {
    private static final int SAMPLES = 64;

    private int n;
    private float[] amp, k1, k2, w1, w2, ph;
    private int[] col, core;
    private final Path path = new Path();
    private final Paint glowP = new Paint(Paint.ANTI_ALIAS_FLAG), coreP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bg = new Paint(), dots = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float[] dotPts;
    private Bitmap halo, pin;
    private float pluck, pluckX;

    @Override
    protected void onSetup() {
        n = U.clamp(Math.round(6 + 4 * cfg.density), 5, 16);
        amp = new float[n];
        k1 = new float[n];
        k2 = new float[n];
        w1 = new float[n];
        w2 = new float[n];
        ph = new float[n];
        col = new int[n];
        core = new int[n];
        for (int i = 0; i < n; i++) {
            amp[i] = h * U.rand(0.05f, 0.14f);
            k1[i] = U.rand(0.8f, 1.8f);
            k2[i] = U.rand(2f, 3.6f);
            w1[i] = U.rand(0.5f, 1.2f) * (U.R.nextBoolean() ? 1f : -1f);
            w2[i] = U.rand(0.3f, 0.9f);
            ph[i] = U.rand(0, U.TAU);
            col[i] = U.mix(pal.a, pal.b, n == 1 ? 0f : i / (float) (n - 1));
            core[i] = U.alpha(U.mix(col[i], U.WHITE, 0.25f), 230);
        }
        glowP.setStyle(Paint.Style.STROKE);
        glowP.setStrokeWidth(9f * scale);
        glowP.setStrokeCap(Paint.Cap.ROUND);
        glowP.setXfermode(U.add());
        coreP.setStyle(Paint.Style.STROKE);
        coreP.setStrokeWidth(2.2f * scale);
        coreP.setStrokeCap(Paint.Cap.ROUND);
        coreP.setXfermode(U.add());
        bg.setShader(U.vgrad(0, h, new int[]{pal.bgTop, pal.bgBottom, pal.bgTop}, new float[]{0f, 0.5f, 1f}));

        float gap = 26f * scale;
        int gx = (int) (w / gap) + 1, gy = (int) (h / gap) + 1;
        dotPts = new float[gx * gy * 2];
        int k = 0;
        for (int i = 0; i < gx; i++)
            for (int j = 0; j < gy; j++) {
                dotPts[k++] = i * gap + gap / 2f;
                dotPts[k++] = j * gap + gap / 2f;
            }
        dots.setColor(U.alpha(pal.b, 34));
        dots.setStrokeWidth(2f * scale);
        dots.setStrokeCap(Paint.Cap.ROUND);

        halo = U.glow(pal.a, false);
        pin = U.glow(pal.c, true);
        pluck = 0f;
    }

    @Override
    protected void update(float dt, float realDt) {
        pluck *= (float) Math.exp(-1.3 * realDt);
    }

    @Override
    protected void draw(Canvas c) {
        c.drawRect(0, 0, w, h, bg);
        c.drawPoints(dotPts, dots);
        float cy = h * 0.5f;
        sprite(c, halo, w / 2f, cy, w * 0.9f, 70);
        float pp = par() * 1.2f;
        for (int i = 0; i < n; i++) {
            path.reset();
            for (int s = 0; s <= SAMPLES; s++) {
                float u = s / (float) SAMPLES;
                float x = u * w;
                float env = (float) Math.pow(U.sin(u * (float) Math.PI), 0.8);
                float y = cy + env * amp[i] * (0.75f * U.sin(u * k1[i] * U.TAU + time * w1[i] + ph[i] + pp)
                        + 0.25f * U.sin(u * k2[i] * U.TAU - time * w2[i] + ph[i] * 1.3f));
                if (pluck > 0.01f) {
                    float d = (x - pluckX) / (w * 0.16f);
                    y += pluck * h * 0.08f * (float) Math.exp(-d * d) * U.sin(time * 18f + i * 0.9f) * env;
                }
                if (s == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            glowP.setColor(U.alpha(col[i], 60));
            c.drawPath(path, glowP);
            coreP.setColor(core[i]);
            c.drawPath(path, coreP);
        }
        sprite(c, pin, 0f, cy, 26f * scale, 220);
        sprite(c, pin, w, cy, 26f * scale, 220);
    }

    @Override
    protected void onTouch(float x, float y, int action) {
        if (!isPress(action)) return;
        pluck = 1f;
        pluckX = x;
    }
}
