package com.neondrift.wallpaper;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;

import java.io.File;

/** Превью видео-обоев: заполняет рамку с обрезкой краёв, звук — по желанию. */
final class VideoPreviewView extends TextureView implements TextureView.SurfaceTextureListener {
    private MediaPlayer mp;
    private Surface surface;
    private String path;
    private boolean active, prepared;
    private int vw, vh;
    private float volume;

    VideoPreviewView(Context c) {
        super(c);
        setSurfaceTextureListener(this);
    }

    void setVideo(String p) {
        active = true;
        if (p != null && p.equals(path) && mp != null) {
            resume();
            return;
        }
        path = p;
        restart();
    }

    /** Громкость звука ролика в превью (0 — без звука). */
    void setSoundVolume(float v) {
        volume = v;
        if (mp != null) {
            try {
                mp.setVolume(v, v);
            } catch (IllegalStateException ignored) {
            }
        }
    }

    void stop() {
        active = false;
        releasePlayer();
    }

    void pause() {
        if (mp != null && prepared) {
            try {
                mp.pause();
            } catch (IllegalStateException ignored) {
            }
        }
    }

    void resume() {
        if (active && mp != null && prepared) {
            try {
                mp.start();
            } catch (IllegalStateException ignored) {
            }
        }
    }

    private void restart() {
        releasePlayer();
        if (!active || surface == null || path == null || !new File(path).exists()) return;
        try {
            MediaPlayer m = new MediaPlayer();
            mp = m;
            m.setSurface(surface);
            m.setDataSource(path);
            m.setLooping(true);
            m.setVolume(volume, volume);
            m.setOnVideoSizeChangedListener((p, w, h) -> fit(w, h));
            m.setOnPreparedListener(p -> {
                if (p != mp) return;
                prepared = true;
                fit(p.getVideoWidth(), p.getVideoHeight());
                if (active) p.start();
            });
            m.setOnErrorListener((p, what, extra) -> {
                if (p == mp) releasePlayer();
                return true;
            });
            m.prepareAsync();
        } catch (Exception e) {
            releasePlayer();
        }
    }

    private void fit(int w, int h) {
        if (w > 0 && h > 0) {
            vw = w;
            vh = h;
        }
        if (vw <= 0 || vh <= 0 || getWidth() == 0 || getHeight() == 0) return;
        float viewW = getWidth(), viewH = getHeight();
        float s = Math.max(viewW / vw, viewH / vh);
        Matrix m = new Matrix();
        m.setScale(vw * s / viewW, vh * s / viewH, viewW / 2f, viewH / 2f);
        setTransform(m);
    }

    private void releasePlayer() {
        if (mp != null) {
            try {
                mp.release();
            } catch (Exception ignored) {
            }
        }
        mp = null;
        prepared = false;
    }

    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
        surface = new Surface(st);
        if (active) restart();
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {
        fit(0, 0);
    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        releasePlayer();
        if (surface != null) surface.release();
        surface = null;
        return true;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture st) {
    }
}
