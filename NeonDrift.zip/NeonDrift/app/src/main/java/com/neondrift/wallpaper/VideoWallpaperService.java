package com.neondrift.wallpaper;

import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.io.File;

/**
 * Видео-обои. Отдельный сервис: поверхность отдаётся плееру целиком
 * и никогда не рисуется через Canvas, иначе плеер не сможет к ней подключиться.
 * Звук: тишина, звук самого ролика или отдельный трек.
 */
public class VideoWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new VideoEngine();
    }

    final class VideoEngine extends Engine implements SharedPreferences.OnSharedPreferenceChangeListener {
        private final Handler main = new Handler(Looper.getMainLooper());
        private final Runnable reload = this::reloadConfig;
        private final WallSound track = new WallSound();

        private SharedPreferences prefs;
        private WallConfig cfg = new WallConfig();
        private MediaPlayer player;
        private String playing;
        private boolean visible, prepared, surfaceOk;
        /** Можно ли звучать — вычисляется до запуска своих плееров. */
        private boolean soundAllowed;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            prefs = WallConfig.prefs(VideoWallpaperService.this);
            prefs.registerOnSharedPreferenceChangeListener(this);
            cfg = WallConfig.load(VideoWallpaperService.this);
            setTouchEventsEnabled(false);
            track.configure(trackPath(), cfg.soundVolume);
        }

        @Override
        public void onDestroy() {
            if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
            main.removeCallbacks(reload);
            releasePlayer();
            track.release();
            super.onDestroy();
        }

        @Override
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            surfaceOk = true;
            start();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            surfaceOk = false;
            releasePlayer();
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) soundAllowed = checkAllowed();
            if (player == null) {
                if (v) start();
            } else if (prepared) {
                try {
                    if (v) player.start();
                    else player.pause();
                } catch (IllegalStateException ignored) {
                }
            }
            applyAudio();
        }

        @Override
        public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
            main.removeCallbacks(reload);
            main.postDelayed(reload, 150);
        }

        private void reloadConfig() {
            cfg = WallConfig.load(VideoWallpaperService.this);
            String path = cfg.videoPath;
            boolean changed = path == null ? playing != null : !path.equals(playing);
            if (changed) releasePlayer();
            track.configure(trackPath(), cfg.soundVolume);
            if (visible) soundAllowed = checkAllowed();
            if (changed) start();
            applyAudio();
        }

        private String trackPath() {
            return "track".equals(cfg.videoSound) ? cfg.soundPath : null;
        }

        private boolean checkAllowed() {
            boolean ours = track.isActive();
            if (!ours && player != null && prepared && "video".equals(cfg.videoSound)) {
                try {
                    ours = player.isPlaying();
                } catch (IllegalStateException ignored) {
                }
            }
            return WallSound.allowed(VideoWallpaperService.this, cfg.soundSilent, ours);
        }

        private void applyAudio() {
            boolean ok = visible && soundAllowed;
            boolean videoSound = ok && "video".equals(cfg.videoSound);
            if (player != null && prepared) {
                float v = videoSound ? cfg.soundVolume * cfg.soundVolume : 0f;
                try {
                    player.setVolume(v, v);
                } catch (IllegalStateException ignored) {
                }
            }
            track.setPlaying(ok && "track".equals(cfg.videoSound));
        }

        private void start() {
            if (!surfaceOk || player != null) return;
            String path = cfg.videoPath;
            if (path == null || !new File(path).exists()) return;
            try {
                MediaPlayer mp = new MediaPlayer();
                player = mp;
                playing = path;
                prepared = false;
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                        .build());
                mp.setSurface(getSurfaceHolder().getSurface());
                mp.setDataSource(path);
                mp.setLooping(true);
                mp.setVolume(0f, 0f);
                mp.setOnPreparedListener(p -> {
                    if (p != player) return;
                    prepared = true;
                    try {
                        p.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING);
                    } catch (Exception ignored) {
                    }
                    applyAudio();
                    if (visible) p.start();
                });
                mp.setOnErrorListener((p, what, extra) -> {
                    if (p == player) releasePlayer();
                    else p.release();
                    return true;
                });
                mp.prepareAsync();
            } catch (Exception e) {
                releasePlayer();
            }
        }

        private void releasePlayer() {
            if (player != null) {
                try {
                    player.release();
                } catch (Exception ignored) {
                }
            }
            player = null;
            playing = null;
            prepared = false;
        }
    }
}
