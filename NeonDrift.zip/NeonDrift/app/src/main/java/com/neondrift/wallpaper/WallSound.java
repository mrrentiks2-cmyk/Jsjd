package com.neondrift.wallpaper;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.File;

/**
 * Звуковая дорожка обоев: играет по кругу, плавно появляется и затихает,
 * ставится на паузу, когда обоев не видно.
 */
final class WallSound {
    private static final long STEP_MS = 40;
    private static final float FADE_IN_S = 0.6f, FADE_OUT_S = 0.35f;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable fader = this::fadeStep;

    private MediaPlayer mp;
    private String path;
    private boolean prepared, wanted;
    private float target = 0.36f, current = 0f;

    /** Трек и громкость 0..1 (слайдер). Пустой путь — тишина. */
    void configure(String newPath, float volume) {
        float v = U.clamp(volume, 0f, 1f);
        target = v * v; // громкость на слух ближе к квадрату амплитуды
        if (newPath == null || !new File(newPath).exists()) {
            release();
            return;
        }
        if (newPath.equals(path) && mp != null) {
            kick();
            return;
        }
        release();
        path = newPath;
        try {
            MediaPlayer m = new MediaPlayer();
            mp = m;
            m.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            m.setDataSource(newPath);
            m.setLooping(true);
            m.setVolume(0f, 0f);
            m.setOnPreparedListener(p -> {
                if (p != mp) return;
                prepared = true;
                kick();
            });
            m.setOnErrorListener((p, what, extra) -> {
                if (p == mp) release();
                else p.release();
                return true;
            });
            m.prepareAsync();
        } catch (Exception e) {
            release();
        }
    }

    void setPlaying(boolean play) {
        if (play == wanted) return;
        wanted = play;
        kick();
    }

    /** Наш трек сейчас играет или вот-вот начнёт. */
    boolean isActive() {
        if (mp == null) return false;
        if (wanted) return true;
        try {
            return prepared && mp.isPlaying();
        } catch (IllegalStateException e) {
            return false;
        }
    }

    void release() {
        handler.removeCallbacks(fader);
        if (mp != null) {
            try {
                mp.release();
            } catch (Exception ignored) {
            }
        }
        mp = null;
        path = null;
        prepared = false;
        current = 0f;
    }

    private void kick() {
        if (mp == null || !prepared) return;
        if (wanted) {
            try {
                if (!mp.isPlaying()) mp.start();
            } catch (IllegalStateException e) {
                return;
            }
        }
        handler.removeCallbacks(fader);
        handler.post(fader);
    }

    private void fadeStep() {
        if (mp == null || !prepared) return;
        float goal = wanted ? target : 0f;
        float step = (STEP_MS / 1000f) * (goal > current ? Math.max(target, 0.05f) / FADE_IN_S : 1f / FADE_OUT_S);
        if (Math.abs(goal - current) <= step) current = goal;
        else current += goal > current ? step : -step;
        try {
            mp.setVolume(current, current);
            if (current != goal) {
                handler.postDelayed(fader, STEP_MS);
            } else if (goal == 0f && mp.isPlaying()) {
                mp.pause();
            }
        } catch (IllegalStateException ignored) {
        }
    }

    /**
     * Можно ли сейчас звучать: в беззвучном режиме молчим (если так настроено),
     * и не перебиваем музыку, которую уже играет другое приложение.
     */
    static boolean allowed(Context ctx, boolean respectSilent, boolean alreadyOurs) {
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return true;
        if (respectSilent && am.getRingerMode() != AudioManager.RINGER_MODE_NORMAL) return false;
        return alreadyOurs || !am.isMusicActive();
    }
}
